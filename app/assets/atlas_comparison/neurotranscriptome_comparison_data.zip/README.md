# Neurotranscriptome: comparison source data

These are the complete original TPM tables, including unmatched genes and all
source sample columns. They are byte-for-byte decompressions of the bundled
source files. No gene rows or values have been renamed, filtered, or summed in
these downloads. The tables contain TPM, not sequencing reads or raw counts.

## Contents

- `published_tpm.tsv`: 16,176 original rows × 122 samples.
- `reprocessed_tpm.tsv`: 19,920 genes × 125 samples.
- `gene_matching.tsv`: the 9,832 one-to-one pairs used in the analysis,
  with mapping methods, source-table evidence, per-gene statistics and PCA flags.
- `sample_matching.tsv`: original sample columns in comparison order;
  `included_in_comparison` selects the 122 compared samples.
  3 extra reprocessed samples are explicitly marked as excluded.
- `sample_metadata.tsv`: original published sample annotations. Its `sample`
  (ovary) or `library_id` (neurotranscriptome) matches `published_sample`.
- `analysis_summary.json`: statistics and PCA settings shown on the website.
- `mapping_sources.json`: source filenames, citations and checksums for mapping evidence.
- `manifest.json`: input provenance, dimensions and SHA-256 checksums.

## Align the tables

Use the exported gene and sample matching; do not match names or column position.
The published ID column is `Vectorbase Identifier`; the reprocessed ID is `gene_id`.
There are 22 extra published rows with repeated identifiers. Sum TPM
for each repeated original ID **before** selecting matched genes, as the analysis
does. Keep the complete original rows when inspecting the source data.

```python
import json
import numpy as np
import pandas as pd

manifest = json.load(open("manifest.json"))
published = pd.read_csv("published_tpm.tsv", sep="\t")
reprocessed = pd.read_csv("reprocessed_tpm.tsv", sep="\t")
genes = pd.read_csv("gene_matching.tsv", sep="\t")
samples = pd.read_csv("sample_matching.tsv", sep="\t")
samples = samples[samples.included_in_comparison].sort_values("comparison_order")
published = published.groupby(manifest["published_id_column"], sort=False)[samples.published_sample].sum()
x = published.loc[genes.published_id, samples.published_sample].to_numpy(float)
y = reprocessed.set_index("gene_id").loc[genes.reanalysis_id, samples.reprocessed_sample].to_numpy(float)
xp, yp = np.log2(x + 1), np.log2(y + 1)
print("Pearson r:", np.corrcoef(xp.ravel(), yp.ravel())[0, 1])
print("Median absolute log2 error:", np.median(np.abs(yp - xp)))
```

For PCA, use the per-panel `used_for_*_pca` flags in `gene_matching.tsv`,
log2(TPM + 1), and centered genes without unit-variance scaling. The summary
records the full selection protocol. Sample identity uses all matched genes.
Unmatched genes stay in the source tables but are excluded from comparison
statistics. Identical original IDs or explicit published links establish pairs;
ambiguous links are excluded. No new gene mapping is performed by this export.

Paper: https://doi.org/10.1186/s12864-015-2239-0
Reprocessed reads: https://www.ncbi.nlm.nih.gov/bioproject/PRJNA236239
Analysis code: https://github.com/Skovorp/rna/tree/main/analysis
